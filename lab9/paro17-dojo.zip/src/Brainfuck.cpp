#include "Brainfuck.hpp"
#include "Memory.hpp"

std::string Brainfuck::interpret(Code const& code, Input const& input) const {
    Memory memory;
    std::string result;

    // TODO

    return result;
}
